package fx;

import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.paint.Color;

public class DbNode extends GridPane {
    
    public Zellentest eingabe;
    public Label head;
    
    public DbNode(String titel) {
	head = new Label(titel);
	eingabe = new Zellentest();
	
	RowConstraints rc = new RowConstraints();
	rc.setPercentHeight(40);
	this.getRowConstraints().addAll(rc);
	
	head.setPrefSize(100000, 100000);
	eingabe.setPrefSize(100000, 100000);
	
	head.setBackground(new Background(new BackgroundFill(Color.CHARTREUSE, CornerRadii.EMPTY, Insets.EMPTY)));
	
	this.add(head, 0, 0);
	this.add(eingabe, 0, 1);
    }
    
    public String getText() {
	return eingabe.getText();
    }
    
    public void setText(String text) {
	eingabe.setText(text);
    }


}
