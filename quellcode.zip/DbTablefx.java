package fx;

import java.util.ArrayList;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.control.Slider;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class DbTablefx extends GridPane {
    
    private ArrayList<Zellefx[]> zellen;
    private String[][] zellenvorschl�ge;
    protected ArrayList<Zeilenpanel> zpanels;
    protected zeilenpanelmodus zpm = zeilenpanelmodus.SINGLE_SELECTION;
    protected ArrayList<String> selectedPanels;
    protected String[] spaltentitel;
    private TextField[] tfs;
    protected ScrollPane scrollpane;
    protected GridPane gp;
    private HBox box;
    private ScrollPane sp;
    
    private SplitPane split;
    
    private int DEFAULT_PREF_WIDTH = 150;
    private int DEFAULT_PREF_HEIGHT = 75;
    
    DbTablefx() {
	
	this.setVgap(5);
	this.setHgap(5);
	this.setPadding(new Insets(5));
	
	zellen = new ArrayList<Zellefx[]>();
	selectedPanels = new ArrayList<String>();
	zpanels = new ArrayList<Zeilenpanel>();
    }
    
    public void setHeader(String[] header, String[][] vorschl�ge) throws IllegalArgumentException {
	
	RowConstraints rc1 = new RowConstraints();
	rc1.setPercentHeight(95);
	
	box = new HBox(5);
	box.setPadding(new Insets(5, 5, 5, 15));
	box.setAlignment(Pos.BASELINE_CENTER);
	box.setMaxSize(100000, 100000);
	this.setHgrow(box, Priority.ALWAYS);
	this.setVgrow(box, Priority.ALWAYS);
	
	sp = new ScrollPane();
	sp.setVbarPolicy(ScrollBarPolicy.NEVER);
	sp.setHbarPolicy(ScrollBarPolicy.NEVER);
	
	zellenvorschl�ge = vorschl�ge;
	spaltentitel = header;
	tfs = new TextField[header.length];
	for (int i = 0; i < header.length; i++) {
	    tfs[i] = createHeaderCell(header[i]);
	    box.getChildren().add(tfs[i]);
	    box.setHgrow(tfs[i], Priority.ALWAYS);
	}
	this.add(box, 0, 0);
	sp.setContent(box);
	this.getRowConstraints().setAll(rc1);
    }
    
    public void createBody() {
	
	gp = new GridPane();
	gp.setHgap(5);
	gp.setVgap(5);
	gp.setPadding(new Insets(5));
	gp.setMaxSize(100000, 100000);
	
	scrollpane = new ScrollPane();
	scrollpane.setPrefSize(100000, 100000);
	scrollpane.setVbarPolicy(ScrollBarPolicy.ALWAYS);
	scrollpane.setHbarPolicy(ScrollBarPolicy.ALWAYS);
	scrollpane.setContent(gp);
	
	scrollpane.hvalueProperty().addListener(new ChangeListener<Number>() {
	    @Override
	    public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
		sp.setHvalue(newValue.doubleValue());
	    }
	});
	
	sp.hvalueProperty().addListener(new ChangeListener<Number>() {
	    @Override
	    public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
		scrollpane.setHvalue(newValue.doubleValue());
	    }
	});
	
	Slider s = new Slider(0.3, 5, 1);
	s.setShowTickLabels(true);
	s.setShowTickMarks(true);
	s.setMajorTickUnit(0.2);
	s.setBlockIncrement(0.2);
	s.valueProperty().addListener(new ChangeListener<Number>() {
	    @Override
	    public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
		setCellSize(newValue.doubleValue());
	    }
	});
	this.add(s, 0, 1);
	
	split = new SplitPane(sp, scrollpane);
	split.setOrientation(Orientation.VERTICAL);
	split.setPrefSize(100000, 100000);
	split.setResizableWithParent(sp, true);
	split.setResizableWithParent(scrollpane, true);
	split.setDividerPositions(0.09);
	this.add(split, 0, 0);
    }
    
    public void addColumn(String[] werte) {
	if (werte == null) {
	    werte = new String[spaltentitel.length];
	    for (int i = 0; i < spaltentitel.length; i++) {
		werte[i] = "";
	    }
	}
	gp.add(createNewCellColumn(zellen.size(), werte), 0, gp.getChildren().size(), 1, 1);
    }
    
    public void removeSelectedColumns() {
	/*
	 * L�scht die markierten Zeilen.
	 * Daf�r m�ssen alle Zeilenpanel von der Komponente entfernt werden und nachher wieder hinzugef�gt werden, da
	 * jedes zpanel ja eine feste Position in der GridPane besitzt und somit entweder Zeilen in der GridPane �berschrieben
	 * werden w�rden oder leer blieben
	 */
	for (int i = 0; i < zpanels.size(); i++) {
	    if (zpanels.get(i).isSelected()) {
		zpanels.remove(i);
		zellen.remove(i);
		i--;
	    }
	}
	gp.getChildren().clear();
	for (int i = 0; i < zpanels.size(); i++) {
	    gp.add(zpanels.get(i), 0, i);
	    for (int j = 0; j < zellen.get(i).length; j++) {
		zellen.get(i)[j].zeile = i;
	    }
	}
    }
    
    public ArrayList<Zellefx[]> getCells() {
	return zellen;
    }
    
    public void setCells(ArrayList<Zellefx[]> z) {
	zellen = z;
    }
    
    public void setModus(zeilenpanelmodus modus) { zpm = modus; }
    public zeilenpanelmodus getModus() { return zpm; }
    
    public void setText(int zeile, String[] eingaben) {
   	for (int i = 0; i < eingaben.length; i++) {
   	    zellen.get(zeile)[i].setText(eingaben[i]);
   	    zellen.get(zeile)[i].setFont(Font.getDefault());
   	}
    }
       
    public String[] getText(int zeile) {
	String[] ausgaben = new String[zellen.get(zeile).length];
	for (int i = 0; i < ausgaben.length; i++) {
	    ausgaben[i] = zellen.get(zeile)[i].getText();
	}
	return ausgaben;
    }
    
    public String[] getSpaltentitel() {
	return spaltentitel;
    }
    
    public int getSpaltenanzahl() {
	return spaltentitel.length;
    }
    
    private TextField createHeaderCell(String headertext) {
	TextField tf = new TextField();
	tf.setEditable(false);
	tf.setPadding(new Insets(5, 10, 5, 10));
	tf.setBackground(new Background(new BackgroundFill(Color.GOLD, CornerRadii.EMPTY, Insets.EMPTY)));
	tf.setPrefSize(150, 75);
	tf.setText(headertext);
	tf.widthProperty().addListener(new ChangeListener<Number>() {
	    @Override
	    public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
		if (tf.getHeight() > 0) {
		    tf.setFont(Font.font(newValue.doubleValue() / ((tf.getWidth() * 3) / tf.getHeight())));
		}
	    }
	});
	
	return tf;
    }
    
    private Zeilenpanel createNewCellColumn(int zeile, String[] texte) {
	Zeilenpanel zp = new Zeilenpanel(zeile);
	zp.setPadding(new Insets(10));
	zp.setHgap(5);
	zp.setOnMouseClicked(new EventHandler<MouseEvent>() {
	    @Override
	    public void handle(MouseEvent event) {
		if (zpm.equals(zeilenpanelmodus.SINGLE_SELECTION)) {
		    if (zp.isSelected()) {
			zp.deselect();
		    } else {
			for (int i = 0; i < zpanels.size(); i++) {
			    if (zpanels.get(i).isSelected()) {
				zpanels.get(i).deselect();
			    }
			    zp.select();
			}
		    }
		} else {
		    if (zp.isSelected()) {
			zp.deselect();
		    } else {
		   	zp.select();
		    }
		}
	    }
	});
	gp.setVgrow(zp, Priority.ALWAYS);
	gp.setHgrow(zp, Priority.ALWAYS);
	Zellefx[] felder = new Zellefx[spaltentitel.length];
	for (int i = 0; i < spaltentitel.length; i++) {
	    felder[i] = createNewCell(texte[i]);
	    felder[i].setZeile(zp.getZeile());
	    zp.add(felder[i], i, 0);
	    zp.setHgrow(felder[i], Priority.ALWAYS);
	    zp.setVgrow(felder[i], Priority.ALWAYS);
	}
	zellen.add(felder);
	zpanels.add(zp);
	return zp;
    }
    
    private Zellefx createNewCell(String text) {
	Zellefx z = new Zellefx();
	z.setBackground(new Background(new BackgroundFill(Color.CHARTREUSE, CornerRadii.EMPTY, Insets.EMPTY)));
	z.setText(text);
	
	z.setOnMouseClicked(new EventHandler<MouseEvent>() {
	    @Override
	    public void handle(MouseEvent event) {
		createNewCheck cnc = new createNewCheck();
		cnc.showOpenDialog(getCells().get(z.zeile), zellenvorschl�ge);
		String[] Rechnungstexte = cnc.getResult();
		setText(z.zeile, Rechnungstexte);
	    }
	});
	
	z.widthProperty().addListener(new ChangeListener<Number>() {
	    @Override
	    public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
		if (z.getHeight() > 0) {
		    z.setFont(Font.font(newValue.doubleValue() / ((z.getWidth() * 3) / z.getHeight())));
		}
	    }
	});
	
	
	return z;
    }
    
    private void setCellSize(double multiplikator) {
	System.out.println("multiplikator: " + multiplikator);
	for (int i = 0; i < zellen.size(); i++) {
	    for (int j = 0; j < zellen.get(i).length; j++) {
		zellen.get(i)[j].setPrefSize(DEFAULT_PREF_WIDTH * multiplikator, DEFAULT_PREF_HEIGHT * multiplikator);
	    }
	}
	for (int i = 0; i < tfs.length; i++) {
	    tfs[i].setPrefSize(DEFAULT_PREF_WIDTH * multiplikator, DEFAULT_PREF_HEIGHT * multiplikator);
	}
	split.setDividerPositions(0.1 * multiplikator - (multiplikator * 0.01));
    }

}

class Zeilenpanel extends GridPane {
    
    private boolean isSelected = false;
    private int zeile;
    
    Zeilenpanel(int zeile) {
	super();
	this.zeile = zeile;
	this.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));
    }
    
    public boolean isSelected() {
	return isSelected;
    }
    
    public void setSelected(boolean b) {
	if (b) {
	    this.select();
	} else {
	    this.deselect();
	}
    }
    
    public void select() {
	isSelected = true;
	this.setBackground(new Background(new BackgroundFill(Color.CORNFLOWERBLUE, CornerRadii.EMPTY, Insets.EMPTY)));
    }
    
    public void deselect() {
	isSelected = false;
	this.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));
    }
    
    public int getZeile() {
	return zeile;
    }
    
    public void setZeile(int zeile) {
	this.zeile = zeile;
    }
    
}

enum zeilenpanelmodus {
    SINGLE_SELECTION,
    MULTIPLE_SELECTION;
}
