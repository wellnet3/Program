package fx;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JScrollPane;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.TextField;

public class Zellentest extends TextField {
    
    protected String[] vorschl�ge;
    
    protected JFrame frame;
    protected JList<String> liste;
    protected DefaultListModel<String> model;
    protected JScrollPane scrollpane;
    
    Zellentest() {
	super();
	this.setMinSize(75, 37.5);
	this.setPrefSize(150, 75);
	initFrame();
	
	this.focusedProperty().addListener(new ChangeListener<Boolean>() {
	    @Override
	    public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
		if (newValue) {
		    frame.setBounds((int) localToScreen(getBoundsInLocal()).getMinX(), (int) localToScreen(getBoundsInLocal()).getMaxY(), (int) getWidth(), 200);
		    aktualisiereVorschl�ge(getText());
		    frame.setVisible(true);
		    liste.setBounds(0, 0, frame.getWidth(), frame.getHeight());
		    scrollpane.setBounds(0, 0, frame.getWidth(), frame.getHeight());
		} else {
		    if (!frame.hasFocus()) {
			frame.setVisible(false);
		    } else {
			
		    }
		}
	    }
	});
	
	this.textProperty().addListener(new ChangeListener<String>() {
	    @Override
	    public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
		aktualisiereVorschl�ge(newValue);
	    }
	});
    }
    
    public void setVorschl�ge(String[] vorschl�ge) {
	for (int i = 0; i < vorschl�ge.length; i++) {
	    model.addElement(vorschl�ge[i]);
	}
	this.vorschl�ge = vorschl�ge;
    }
    
    private void aktualisiereVorschl�ge(String eingabe) {
	if (eingabe == null) {
	    eingabe = "";
	}
	if (vorschl�ge == null) {
	    System.out.println("keine vorschl�ge vorhanden");
	    return;
	}
	model.clear();
	for (int i = 0; i < vorschl�ge.length; i++) {
	    if (vorschl�ge[i].contains(eingabe)) {
		model.addElement(vorschl�ge[i]);
	    }
	}
    }
    
    private void initFrame() {
	frame = new JFrame();
	frame.setUndecorated(true);
	frame.setAlwaysOnTop(true);
	frame.setLayout(null);
	frame.setBackground(Color.blue);
	frame.setBounds(0, 0, (int) this.getWidth(), (int) this.getHeight());
	frame.setFocusableWindowState(false);
	
	liste = new JList<String>();
	model = new DefaultListModel<String>();
	liste.setModel(model);
	liste.setBounds(0, 0, frame.getWidth(), frame.getHeight());
	
	liste.addMouseListener(new MouseAdapter() {
	    @Override
	    public void mouseClicked(MouseEvent e) {
		setText(liste.getModel().getElementAt(liste.getSelectedIndex()));
		frame.setVisible(false);
	    }
	});
	
	scrollpane = new JScrollPane(liste, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	scrollpane.setBounds(0, 0, frame.getWidth(), frame.getHeight());
	frame.add(scrollpane);
	scrollpane.setViewportView(liste);
	frame.setVisible(false);
    }
    
    public void setProfilCell(Zellentest[] profilzellen) {
	liste.removeMouseListener(liste.getMouseListeners()[liste.getMouseListeners().length -1]);
	liste.addMouseListener(new MouseAdapter() {
	    @Override
	    public void mouseClicked(MouseEvent e) {
		String profiltext = liste.getModel().getElementAt(liste.getSelectedIndex());
		for (int i = 0; i < profilzellen.length; i++) {
		    if (i != profilzellen.length -1) {
			profilzellen[i].setText(profiltext.substring(0, profiltext.indexOf("   ")));
			profiltext = profiltext.substring(profiltext.indexOf("   ") +1);
		    } else {
			profilzellen[i].setText(profiltext);
		    }
		}
		frame.setVisible(false);
	    }
	});
    }

}
