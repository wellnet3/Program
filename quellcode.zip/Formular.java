package fx;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.Enumeration;
import java.util.Objects;
import java.util.zip.CRC32;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import javax.swing.JOptionPane;

public class Formular {
    
    private static String[] ursprungsw�rter = new String[] { "«Firma»", "«Anrede»", "«Vorname»", "«Name»", "«Anschrift»", "«Anschrift2»", "«PLZ»",
	    "«Ort»", "«Rechnungsnummer»", "«Datum»", "«Text»", "«Hinweis»", "«Frist»", "«Kategorie»", "«Betrag»", "«Betrag_MwSt»", "«Gesamt»" };
    
    
    Formular() {
	
    }
    
    public static void createFormular(String[] optionen, FormularForm ff) throws IOException {
	/*
	 * optionen:
	 * 
	 * 1: Firma;
	 * 2: Anrede;
	 * 3: Vorname;
	 * 4: Name;
	 * 5: Anschrift;
	 * 6: Anschrift2;
	 * 7: PLZ;
	 * 8: Ort;
	 * 9: Rechnungsnummer;
	 * 10: Datum;
	 * 11: Text;
	 * 12: Hinweis;
	 * 13: Frist;
	 * 
	 * 14: Kategorie;
	 * 15: Betrag;
	 * 16: Betrag_Mwst;
	 * 17: Gesamt
	 */
	Objects.requireNonNull(optionen, "eingabewerte d�rfen nicht null sein");
	Objects.requireNonNull(ff, "FormularForm darf nicht null sein");
	if (optionen.length != 17) {
	    throw new IllegalArgumentException("nicht gen�gend eingabewerte vorhanden");
	}
	
	String odtpath;
	
	//IO.currentpath = "C:\\Users\\User\\Desktop\\Simulation2\\";
	
	if (ff.equals(FormularForm.PRAXIS)) {
	    odtpath = IO.currentpath + "\\Vorlagen\\Vorlage Rechnung Praxis1.odt";
	} else if (ff.equals(FormularForm.PRIVAT)) {
	    odtpath = IO.currentpath + "\\Vorlagen\\Vorlage Rechnung Privat1.odt";
	} else {
	    throw new IllegalArgumentException("?");
	}
	
	final String dest = IO.currentpath + "\\docx\\out.zip";
	
	ZipFile zf = new ZipFile(new File(odtpath));
	final ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(dest));
	for (Enumeration<? extends ZipEntry> e = zf.entries(); e.hasMoreElements(); ) {
	    ZipEntry ze = (ZipEntry) e.nextElement();
	    if (!ze.getName().equals("content.xml")) {
		zos.putNextEntry(ze);
		InputStream is = zf.getInputStream(ze);
		byte[] buf = new byte[1024];
		int len;
		while ((len = is.read(buf)) > 0 ) {
		    zos.write(buf, 0, len);
		}
	    } else {
		InputStream is = zf.getInputStream(ze);
		byte[] bytes = new byte[(int) ze.getSize()];
		for (int i = 0; i < bytes.length; i++) {
		    bytes[i] = (byte) is.read();
		}
		String content = new String(bytes);
		
		content = replaceWithValues(content, optionen);
		
		bytes = content.getBytes();
		ze.setSize(bytes.length);
		
		Deflater compressor = new Deflater();
		compressor.setInput(bytes);
	
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		DeflaterOutputStream defl = new DeflaterOutputStream(out);
		defl.write(bytes);
		defl.flush();
		defl.close();
		ze.setCompressedSize(out.toByteArray().length -6);
		CRC32 crc = new CRC32();
		crc.update(bytes);
		ze.setCrc(crc.getValue());
		zos.putNextEntry(ze);
		zos.write(bytes);
	    }
	    zos.closeEntry();
	}
	zos.close();
	zf.close();
	
	File f = new File(dest);
	if (f.renameTo(new File(new File(dest).getParent() + "\\" + optionen[8] + ".odt"))) {
	    System.out.println("Datei erfolgreich umbenannt");
	} else {
	    JOptionPane.showMessageDialog(null, "Fehler beim verpacken der zip-datei");
	}
	
    }
    
    private static String replaceWithValues(final String eingabe, final String[] werte) {
	String ausgabe = eingabe;
	for (int i = 0; i < ursprungsw�rter.length; i++) {
	    if (werte[i].contains("�")) {
		werte[i] = werte[i].substring(0, werte[i].indexOf('�')).concat("&#x20AC;");
	    }
	    ausgabe = ausgabe.replace(ursprungsw�rter[i], werte[i]);
	}
	return ausgabe;
    }

}

enum FormularForm {
    PRAXIS,
    PRIVAT;
}
