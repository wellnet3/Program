package fx;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class IO {
    
    public static String currentpath = "";
    
    public static void writeData(ArrayList<String[]> data, final String name) throws IOException {
	BufferedWriter out = new BufferedWriter(new FileWriter(currentpath + name));
	for (int i = 0; i < data.size(); i++) {
	    for (int j = 0; j < data.get(i).length; j++) {
		out.write(data.get(i)[j]);
		out.write(";");
	    }
	    out.newLine();
	}
	out.close();
    }
    
    public static ArrayList<String[]> readData(final String name) throws IOException {
	ArrayList<String[]> data = new ArrayList<String[]>();
	BufferedReader in = new BufferedReader(new FileReader(currentpath + name));
	String zeile;
	while ((zeile = in.readLine()) != null) {
	    String[] s = new String[28];
	    for (int i = 0; i < s.length; i++) {
		try {
		    if (zeile.contains(";")) {
			s[i] = zeile.substring(0, zeile.indexOf(";"));
		    	zeile = zeile.substring(zeile.indexOf(";") +1);
		    } else {
			s[i] = zeile;
			break;
		    }
		} catch (NullPointerException npex) {
		    s[i] = zeile;
		}
	    }
	    data.add(s);
	}
	in.close();
	return data;
    }
    
    public static String[][] readListenerVorschl�ge(final String[] namen) throws IOException {
	String[][] data = new String[namen.length][];
	for (int i = 0; i < namen.length; i++) {
	    ArrayList<String> tmp = new ArrayList<String>();
	    String zeile = "";
	    BufferedReader in = null;
	    try {
		in = new BufferedReader(new FileReader(new File(currentpath + "\\TextVorschl�ge\\" + namen[i])));
	    } catch (FileNotFoundException fnfex) {
		File f = new File(currentpath + "\\TextVorschl�ge\\" + namen[i]);
		if(f.createNewFile()) {
		    System.out.println("Datei nicht vorhanden, erstelle neue Datei: " + currentpath + "\\TextVorschl�ge\\" + namen[i]);
		} else {
		    System.out.println("Datei nicht vorhanden, neue Datei konnte nicht erstellt werden");
		}
		readListenerVorschl�ge(namen);
		break;
	    }
	    while ((zeile = in.readLine()) != null) {
		tmp.add(zeile);
	    }
	    if (zeile == null && tmp.isEmpty()) {
		tmp.add("");
	    }
	    String[] cString = new String[tmp.size()];
	    for (int j = 0; j < cString.length; j++) {
		cString[j] = tmp.get(j);
	    }
	    data[i] = cString;
	    in.close();
	}
	return data;
    }
    
    public static String[] readProfile(final String name) throws IOException {
	ArrayList<String> data = new ArrayList<String>();
	BufferedReader in = new BufferedReader(new FileReader(currentpath + name));
	String zeile = "";
	while ((zeile = in.readLine()) != null) {
	    zeile = zeile.replace(",", "   ");
	    data.add(zeile);
	}
	String[] profildata = new String[data.size()];
	for (int i = 0; i < profildata.length; i++) {
	    profildata[i] = data.get(i);
	}
	in.close();
	return profildata;
    }
    
    public static void addProfil(final String name, String data) throws IOException {
	String[] profildata = readProfile(name);
	BufferedWriter out = new BufferedWriter(new FileWriter(currentpath + name));
	for (int i = 0; i < profildata.length; i++) {
	    profildata[i] = profildata[i].replace("   ", ",");
	    out.write(profildata[i]);
	    out.newLine();
	}
	data = data.replace("   ", ",");
	out.write(data);
	out.close();
    }

}
