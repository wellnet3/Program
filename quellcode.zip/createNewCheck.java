package fx;

import java.util.Optional;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.StageStyle;

public class createNewCheck extends Dialog<String[]> {
    
    private DbNode[] nodes;
    private String[] kategorien = new String[] { "Rechnungsnummer", "Datum", "Frist", "Betrag", "Kategorie", "Firma",
		"Anrede", "Vorname", "Name", "Anschrift", "Anschrift2", "PLZ", "Ort", "Name Patient", "Titel Dienstleistung", "Datum Erbringung",
		"Adresse Erbringung", "Entfernung in km", "Honorar", "Reisekosten", "Auslagen f�r Material", "Mwst", "Summe", "Text", "Hinweis",
		"Eingang", "Anmerkung", "Kalenderdaten" };
    private String[] werte;
    
    public createNewCheck() {
	super();
    }
    
    public void showOpenDialog(Zellefx[] zellen, String[][] vorschl�ge) {
	
	/*
	 *erstellt einen Eingabedialog mit mehreren Eingabefeldern.
	 *Hier werden auf einer GridPane mehrere Objekte der Klasse DbNode hinzugef�gt,
	 *welche jeweils ein Label und ein Objekt der Klasse Zellentest beherbergen.
	 *Zuerst werden hier die grafischen Elemente initialisiert.
	 */
	
	this.initStyle(StageStyle.DECORATED);
	this.initModality(Modality.APPLICATION_MODAL);
	this.setTitle("Rechnung bearbeiten");
	this.setResizable(true);
	
	ButtonType speichern = new ButtonType("Speichern", ButtonData.OK_DONE);
	this.getDialogPane().getButtonTypes().addAll(speichern, ButtonType.CANCEL);
	
	this.getDialogPane().setOnMouseClicked(new EventHandler<MouseEvent>() {
	    @Override
	    public void handle(MouseEvent event) {
		System.out.println("clicked");
		for (DbNode node: nodes) {
		    node.eingabe.frame.setVisible(false);
		}
	    }
	});
	
	GridPane gp = new GridPane();
	gp.setHgap(10);
	gp.setVgap(10);
	gp.setPrefSize(600, 450);
	gp.setPadding(new Insets(20));
	gp.setAlignment(Pos.CENTER);
	
	nodes = new DbNode[kategorien.length];
	Zellentest[] profilzellen = new Zellentest[9];
	for (int i = 0; i < nodes.length; i++) {
	    nodes[i] = new DbNode(kategorien[i]);
	    if (i < 6) {
		gp.add(nodes[i], 0, i);
	    } else if (i < 12) {
		gp.add(nodes[i], 1, i -6);
	    } else if (i < 18) {
		gp.add(nodes[i], 2, i -12);
	    } else if (i < 23) {
		gp.add(nodes[i], 3, i -18);
	    } else {
		gp.add(nodes[i], 4, i -23);
	    }
	    gp.setVgrow(nodes[i], Priority.ALWAYS);
	    gp.setHgrow(nodes[i], Priority.ALWAYS);
	    nodes[i].setText(zellen[i].getText());
	    nodes[i].eingabe.setVorschl�ge(vorschl�ge[i]);
	    if (i > 4 && i < 14) {
		profilzellen[i -5] = nodes[i].eingabe;
	    }
	}
	
	/*
	 * Dann werden die Profilzellen extrahiert und ihnen wird ein anderer Listener zugewiesen.
	 */
	
	for (int i = 5; i < 14; i++) {
	    nodes[i].eingabe.setProfilCell(profilzellen);
	}
	
	werte = new String[kategorien.length];
	addColors();
	
	/*
	 * Dann werden den Feldern zur besseren �bersicht noch Farben gegeben
	 * Abschlie�end werden noch "InputListener" hinzugef�gt, welche den Wert von einer angegebenen Zelle automatisch mit den angegebenen
	 * Zellen und Rechenoperationen berechnen.
	 * Dann wird noch der R�ckgabetyp (= Optional<String[]> result) gesetzt und es wird auf eine Akktion gewartet.
	 */
	
	this.getDialogPane().setContent(gp);
	
	addInputListener(new int[] { 17 }, 19, null, 0.3);
	addInputListener(new int[] { 18, 19, 20 }, 21, new String[] { "+", "+" }, 0.19);
	addInputListener(new int[] { 18, 19, 20, 21 }, 22, new String[] { "+", "+", "+" }, 1);
	
	this.setResultConverter(dialogButton -> {
	    if (dialogButton == speichern) {
		for (int i = 0; i < nodes.length; i++) {
		    werte[i] = nodes[i].getText();
		}
		return werte;
	    }
	    return null;
	});
	Optional<String[]> result = this.showAndWait();
    }
    
    private void addColors() {
	nodes[1].eingabe.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, CornerRadii.EMPTY, Insets.EMPTY)));
	nodes[2].eingabe.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, CornerRadii.EMPTY, Insets.EMPTY)));
	for (int i = 5; i < 14; i++) {
	    nodes[i].eingabe.setBackground(new Background(new BackgroundFill(Color.CORNFLOWERBLUE, CornerRadii.EMPTY, Insets.EMPTY)));
	}
	nodes[17].eingabe.setBackground(new Background(new BackgroundFill(Color.GOLD, CornerRadii.EMPTY, Insets.EMPTY)));
	nodes[18].eingabe.setBackground(new Background(new BackgroundFill(Color.GOLD, CornerRadii.EMPTY, Insets.EMPTY)));
	nodes[19].eingabe.setBackground(new Background(new BackgroundFill(Color.GOLDENROD, CornerRadii.EMPTY, Insets.EMPTY)));
	nodes[20].eingabe.setBackground(new Background(new BackgroundFill(Color.GOLD, CornerRadii.EMPTY, Insets.EMPTY)));
	nodes[21].eingabe.setBackground(new Background(new BackgroundFill(Color.GOLDENROD, CornerRadii.EMPTY, Insets.EMPTY)));
	nodes[22].eingabe.setBackground(new Background(new BackgroundFill(Color.GOLDENROD, CornerRadii.EMPTY, Insets.EMPTY)));
    }
    
    private void addInputListener(int[] eingabezellen, int ausgabezelle, String[] Rechenoperationen, double faktor) {
	for (int i = 0; i < eingabezellen.length; i++) {
	    nodes[eingabezellen[i]].eingabe.textProperty().addListener(new ChangeListener<String>() {
		@Override
		public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
		    notifyCell(eingabezellen, ausgabezelle, Rechenoperationen, faktor);
		}
	    });
	}
    }
    
    private void notifyCell(int[] eingabezellen, int ausgabezelle, String[] Rechenoperationen, double faktor) {
	try {
	    double[] eingaben = new double[eingabezellen.length];
	    double value = 0;
	    for (int i = 0; i < eingabezellen.length; i++) {
		if (!nodes[eingabezellen[i]].getText().endsWith("�")) {
		    eingaben[i] = Double.parseDouble(nodes[eingabezellen[i]].getText());
		} else {
		    eingaben[i] = Double.parseDouble(nodes[eingabezellen[i]].getText().replace("�", ""));
		}
	    }
	    value = eingaben[0];
	    for (int i = 0; i < eingaben.length -1; i++) {
		if (eingaben.length == 1) {
		    value = value * faktor;
		    nodes[ausgabezelle].setText(String.valueOf(value));
		    break;
		} else {
		    switch (Rechenoperationen[i]) {
		    case "+":
			value = value + eingaben[i +1];
			break;
		    case "-":
			value = value - eingaben[i +1];
			break;
		    case "*":
			value = value * eingaben[i +1];
			break;
		    case "/":
			value = value / eingaben[i +1];
			break;
		    }
		}
	    }
	    value = value * faktor;
	    nodes[ausgabezelle].setText(String.valueOf(value) + "�");
	} catch (NumberFormatException nfex) {
	    System.out.println("ILLEGAL NUMBER FORMAT");
	    nodes[ausgabezelle].setText("");
	}
    }
    
   
}