package fx;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import javafx.application.Application;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Interface extends Application {
    
    private String[][] listenervorschl�ge;
    private String[] profilvorschl�ge;
    private String[][] vorschl�ge;
    private String[] listenernamen = new String[] { "rechnungsnummer.txt", "datum.txt", "frist.txt", "betrag.txt", "kategorie.txt", "titel dienstleistung.txt",
	    	"datum erbringung.txt", "addresse erbringung.txt", "entfernung in km.txt", "honorar.txt", "reisekosten.txt", "ausgaben f�r material.txt", 
	    	"mwst.txt", "summe.txt", "text.txt", "hinweis.txt", "eingang.txt", "anmerkung.txt", "kalenderdaten.txt" };
    private ArrayList<String[]> daten;
    
    private SplitPane sp;
    private DbTablefx dbtablefx;
    private VBox menu;
    
    private Stage stage;
    
    private Button btnAddRow;
    private Button btnDelRow;
    private Button btnPraxis;
    private Button btnPrivat;
    private Button btnSpeichern;
    private Button btnSelect;
    private Button btnExport;
    private Button btnXlsxImport;
    
    private ObjectProperty<Font> fontTracking = new SimpleObjectProperty<Font>(Font.getDefault());
    
    private static String cversion = "0.12";

    @Override
    public void start(Stage primaryStage) throws Exception {
	
	stage = primaryStage;
	
	/* 
	 * Erzeugt einen neuen Thread, wo �berpr�ft wird, ob es eine neue Version gibt
	 */
	
	Thread t1 = new Thread(new Runnable() {
	    @Override
	    public void run() {
		try {
		    try {
			TimeUnit.SECONDS.sleep(1);
		    } catch (InterruptedException iex) {
			
		    }
		    UpdateManager.update(cversion); //siehe UpdateManager.update(String)
		} catch (URISyntaxException | IOException ex) {
		    ex.printStackTrace();
		    ex.getMessage();
		    System.out.println("Fehler beim Updaten");
		} 
	    }
	});
	t1.start();
	
	try {
	    /*
	     * Bestimmung des Ortes, wo sich das Programm derzeit befindet. Falls es nicht unm�glich ist den Ort zu bestimmen,
	     * wird der Ort nicht gesetzt, um keine NullPointerExceptions zu erzeugen
	     */
	    File f = new File(Interface.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath());
	    IO.currentpath = f.getParent() + "\\";
	} catch (URISyntaxException ex) {
	    IO.currentpath = "";
	    JOptionPane.showMessageDialog(null, "Fehler beim Bestimmen des Ortes");
	}
	//IO.currentpath = "C:\\Users\\User\\Desktop\\Simulation2\\";
		
	einlesen(); //Alle ben�tigten Dateien werden eingelesen, dazu geh�ren die daten, die Profile und die Listenervorschl�ge
	
	dbtablefx = new DbTablefx();
	dbtablefx.setHeader(new String[] { "Rechnungsnummer", "Datum", "Frist", "Betrag", "Kategorie", "Firma",
		"Anrede", "Vorname", "Name", "Anschrift", "Anschrift2", "PLZ", "Ort", "Name Patient", "Titel Dienstleistung", "Datum Erbringung",
		"Adresse Erbringung", "Entfernung in km", "Honorar", "Reisekosten", "Auslagen f�r Material", "Mwst", "Summe", "Text", "Hinweis",
		"Eingang", "Anmerkung", "Kalenderdaten" } , vorschl�ge);
	dbtablefx.createBody();
	try {
	    for (int i = 0; i < daten.size(); i++) {
		dbtablefx.addColumn(daten.get(i));
	    }
	} catch (NullPointerException npex) {
	    System.out.println("keine daten vorhanden");
	}
	
	VBox menu = createMenu();
	
	sp = new SplitPane(dbtablefx, menu);
	sp.setOrientation(Orientation.HORIZONTAL);
	sp.setDividerPositions(0.9);
	
	Scene scene = new Scene(sp, 1920, 1080);
	stage.setTitle("");
	stage.setScene(scene);
	stage.show();
    }
    
    public static void main(String[] args) {
	launch(args);
    }
    
    private VBox createMenu() {
	
	/*
	 * Hier werden alle Buttons mit den dazugeh�rigen setOnAction-Funktionen erzeugt.
	 */
	
	menu = new VBox(10);
	menu.setPadding(new Insets(50, 10, 50, 10));
	menu.setAlignment(Pos.CENTER);
	
	btnAddRow = new Button("+");
	btnDelRow = new Button("-");
	btnPraxis = new Button("Praxis-Formular");
	btnPrivat = new Button("Privat-Formular");
	btnSpeichern = new Button("daten speichern");
	btnSelect = new Button("Selection: Single");
	btnExport = new Button("als .xlsx exportieren");
	btnXlsxImport = new Button(".xlsx datei importieren");
	
	ObservableList<Button> ol = FXCollections.observableArrayList(btnAddRow, btnDelRow, btnPraxis, btnPrivat, btnSpeichern, btnSelect, btnExport, btnXlsxImport);
	
	btnSpeichern.fontProperty().bind(fontTracking);
	btnAddRow.fontProperty().bind(fontTracking);
	btnDelRow.fontProperty().bind(fontTracking);
	btnPraxis.fontProperty().bind(fontTracking);
	btnPrivat.fontProperty().bind(fontTracking);
	btnSelect.fontProperty().bind(fontTracking);
	btnExport.fontProperty().bind(fontTracking);
	btnXlsxImport.fontProperty().bind(fontTracking);
	
	btnAddRow.setOnAction((value) -> {
	    /*
	     * Zuerst wird eine neue Zeile mit den Standartwerten erzeugt (siehe getDefaultWerte())
	     * Dann wird eine Instanz von createNewCheck erzeugt, wobei als Zellen die Zellen der neu erzeugten Zeile genommen werden
	     * Die Ergebnisse aus dem Dialog werden dann in die neue Zeile �bernommen.
	     * Anschlie�end wird die ScrollBar auf das vertikale ende gesetzt und die neu erzeugte Zeile erh�lt denselben Font und dieselebe Gr��e wie
	     * die Zeile dar�ber (falls eine vorhanden ist)
	     * Zuletzt wird noch die Profilinformationen extrahiert und �berpr�ft ob es dieses profil schon gibt.
	     * Wenn es das Profil noch nicht gibt, wird es in der Datei hinzugef�gt.
	     * 
	     */
	    dbtablefx.addColumn(getDefaultWerte());
	    createNewCheck cnc = new createNewCheck();
	    cnc.showOpenDialog(dbtablefx.getCells().get(dbtablefx.getCells().size() -1), vorschl�ge);
	    String[] Rechnungstexte = cnc.getResult();
	    //dbtablefx.setText(dbtablefx.getCells().size() -1, editCheckTODbTable(dbtablefx.getCells().size() -1, Rechnungstexte));
	    dbtablefx.setText(dbtablefx.getCells().size() -1, Rechnungstexte);
	    dbtablefx.scrollpane.setVvalue(dbtablefx.scrollpane.getVmax());
	    try {
		for (int i = 0; i < dbtablefx.getCells().get(0).length; i++) {
		    dbtablefx.getCells().get(dbtablefx.getCells().size() -1)[i].setFont(dbtablefx.getCells().get(0)[0].getFont());
		    dbtablefx.getCells().get(dbtablefx.getCells().size() -1)[i].setPrefSize(dbtablefx.getCells().get(0)[0].getWidth(), dbtablefx.getCells().get(0)[0].getHeight());
		}
	    } catch (ArrayIndexOutOfBoundsException aioobex) {
		System.out.println("keine erste zeile vorhanden");
		//do nothing
	    }
	    String profiltext = "";
	    for (int i = 5; i < 14; i++) {
		profiltext = profiltext.concat(Rechnungstexte[i]).concat(" ");
	    }
	    profiltext = profiltext.substring(0, profiltext.length() -1);
	    boolean istVorhanden = false;
	    if (profilvorschl�ge.length == 9) {
		for (int i = 0; i < profilvorschl�ge.length; i++) {
		    if (profiltext.equals(profilvorschl�ge[i])) {
			istVorhanden = true;
		    }
		}
	    }
	    if (!istVorhanden) {
		try {
		    IO.addProfil("profile.txt", profiltext);
		} catch (IOException ioex) {
		    ioex.printStackTrace();
		    ioex.getMessage();
		    System.out.println("Fehler beim Speichern des neuen Profils");
		}
	    }
	});
	
	btnDelRow.setOnAction((value) -> {
	    /*
	     * L�scht die markierten Zeilen
	     */
	    dbtablefx.removeSelectedColumns();
	});
	
	btnPraxis.setOnAction((value) -> {
	    /*
	     * Erstellt Praxis-Formulare f�r die markierten Zeilen
	     */
	    for (int i = 0; i < dbtablefx.zpanels.size(); i++) {
		if (dbtablefx.zpanels.get(i).isSelected()) {
		    erstellePraxisFormular(dbtablefx.zpanels.get(i).getZeile());
		}
	    }
	});
	
	btnPrivat.setOnAction((value) -> {
	    /*
	     * Erstellt Praxis-Formulare f�r die markierten Zeilen
	     */
	    for (int i = 0; i < dbtablefx.zpanels.size(); i++) {
		if (dbtablefx.zpanels.get(i).isSelected()) {
		    erstellePrivatFormular(dbtablefx.zpanels.get(i).getZeile());
		}
	    }
	});
	
	btnSpeichern.setOnAction((value) -> {
	    /*
	     * F�gt die Daten in eine ArrayList hinzu.
	     * Anschlie�end werden die Daten in "daten.txt" abgespeichert
	     */
	    ArrayList<String[]> data = new ArrayList<String[]>();
	    for (int i = 0; i < dbtablefx.getCells().size(); i++) {
		String[] zeile = new String[dbtablefx.getCells().get(i).length];
		for (int j = 0; j < zeile.length; j++) {
		    zeile[j] = dbtablefx.getCells().get(i)[j].getText();
		    if (zeile[j] == null) {
			zeile[j] = "";
		    }
		}
		data.add(zeile);
	    }
	    try {
		IO.writeData(data, "daten.txt");
		JOptionPane.showMessageDialog(null, "Daten erfolgreich gespeichert");
	    } catch (IOException ioex) {
		ioex.printStackTrace();
		ioex.getMessage();
		System.out.println("Fehler beim Speichern");
	    }
	});
	
	btnSelect.setOnAction((value) -> {
	    /*
	     * �ndert den Selektionsmodus
	     */
	    if (dbtablefx.zpm.equals(zeilenpanelmodus.SINGLE_SELECTION)) {
		dbtablefx.zpm = zeilenpanelmodus.MULTIPLE_SELECTION;
		btnSelect.setText("Selection: Multiple");
	    } else {
		dbtablefx.zpm = zeilenpanelmodus.SINGLE_SELECTION;
		btnSelect.setText("Selection: Single");
	    }
	});
	
	btnExport.setOnAction((value) -> {
	    /*
	     * Exportiert alle Daten als .xlsx-datei in "export.xlsx"
	     */
	    try {
		Excel.exportiere(dbtablefx.getSpaltentitel(), dbtablefx.getCells(), IO.currentpath + "export.xlsx");
	    } catch (IOException ioex) {
		ioex.printStackTrace();
		ioex.getMessage();
		System.out.println("Fehler beim Exportieren");
	    }
	});
	
	btnXlsxImport.setOnAction((value) -> {
	    /*
	     * Importiert Daten aus der Datei "import.xlsx"
	     */
	    try {
		ArrayList<String[]> exceldata = Excel.importiere(IO.currentpath + "import.xlsx");
		for (int i = 0; i < exceldata.size(); i++) {
		    dbtablefx.addColumn(exceldata.get(i));
		}
	    } catch (IOException ioex) {
		ioex.printStackTrace();
		ioex.getMessage();
		System.out.println("Fehler beim importieren");
	    } catch (InvalidFormatException ifex) {
		ifex.printStackTrace();
		ifex.getMessage();
		System.out.println("Ung�ltiges Format");
	    }
	});
	
	/*
	 * Sobald die gr��e von dem Button btnSpeichern ge�ndert wird, �ndert sich auch die Gr��e von den anderen Buttons,
	 * und so wird die neue Font-Gr��e bestimmt.
	 */
	
	btnSpeichern.widthProperty().addListener(new ChangeListener<Number>() {
	    @Override
	    public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
		resize(newValue);
	    }
	});
	
	btnSpeichern.heightProperty().addListener(new ChangeListener<Number>() {
	    @Override
	    public void changed(ObservableValue<? extends Number> observable, Number oldvalue, Number newValue) {
		resize(btnSpeichern.getWidth());
	    }
	});
	
	
	menu.getChildren().addAll(ol);
	for (int i = 0; i < menu.getChildren().size(); i++) {
	    ol.get(i).setMinSize(100, 25);
	    ol.get(i).setMaxSize(100000, 100000);
	    menu.setVgrow(menu.getChildren().get(i), Priority.ALWAYS);
	}
	return menu;
    }
    
    private void einlesen() {
	/*
	 * Liest die ben�tigten Datens�tze ein und kombiniert sie in dem zweidimensionalen String Array vorschl�ge.
	 */
	
	try {
	    daten = IO.readData("daten.txt");
	} catch (IOException ioex) {
	    ioex.printStackTrace();
	    ioex.getMessage();
	    JOptionPane.showMessageDialog(null, "Fehler beim Einlesen der daten");
	}
	
	try {
	    listenervorschl�ge = IO.readListenerVorschl�ge(listenernamen);
	    profilvorschl�ge = IO.readProfile("profile.txt");
	    vorschl�ge = kombinierteVorschl�ge(listenervorschl�ge, profilvorschl�ge);
	} catch (IOException ioex) {
	    ioex.printStackTrace();
	    ioex.getMessage();
	    System.out.println("Fehler beim Einlesen der Listenervorschl�ge");
	}
	
	if (vorschl�ge == null) {
	    vorschl�ge = new String[28][];
	    for (int i = 0; i < vorschl�ge.length; i++) {
		vorschl�ge[i] = new String[] { "" };
	    }
	}
    }
    
    private String[][] kombinierteVorschl�ge(String[][] listenervorschl�ge, String[] profilvorschl�ge) {
	String[][] vorschl�ge = new String[listenervorschl�ge.length +9][];
	for (int i = 0; i < listenervorschl�ge.length +9; i++) {
	    if (i < 5) {
		vorschl�ge[i] = listenervorschl�ge[i];
	    } else if (i >= 5 && i <= 13) {
		vorschl�ge[i] = profilvorschl�ge;
	    } else if (i > 13) {
		vorschl�ge[i] = listenervorschl�ge[i -9];
	    }
	}
	return vorschl�ge;
    }
    
    private void erstellePraxisFormular(int zeile) {
	/*
	 * erstellt ein Praxis-Formular aus, wobei die Rechnugsnummer der Titel der Datei ist, und bestimmte Zelltexte extrahiert werden.
	 */
	try {
	    Formular.createFormular(formularform(zeile), FormularForm.PRAXIS);
	} catch (IOException ioex) {
	    ioex.printStackTrace();
	    ioex.getMessage();
	    System.out.println("Fehler beim erstellen des Formulars");
	}
    }
    
    private void erstellePrivatFormular(int zeile) {
	/*
	 * erstellt ein Privat-Formular aus, wobei die Rechnugsnummer der Titel der Datei ist, und bestimmte Zelltexte extrahiert werden.
	 */
	try {
	    Formular.createFormular(formularform(zeile), FormularForm.PRIVAT);
	}  catch (IOException ioex) {
	    ioex.printStackTrace();
	    ioex.getMessage();
	    System.out.println("Fehler beim erstellen des Formulars");
	}
    }
    
    private String[] formularform(int zeile) {
	/*
	 * konvertiert bestimmte daten aus der zeile in ein Array, die f�r die Formulare ben�tigt werden.
	 */
	String[] daten = new String[17];
	int[] reihenfolge = new int[] { 5, 6, 7, 8, 9, 10, 11, 12, 0, 1, 23, 24, 2, 4, 3, 21, 22 };
	for (int i = 0; i < 17; i++) {
	    daten[i] = dbtablefx.getCells().get(zeile)[reihenfolge[i]].getText();
	}
	return daten;
    }
    
    private String[] getDefaultWerte() {
	/*
	 * Liefert Standartwerte zur�ck; dabei wird die Rechnungsnummer auf +1 der vorherigen Rechnungsnummer gesetzt.
	 * Als Datum wird das derzeitige System-datum genommen und als Frist wird das derzeitige Datum +2 Wochen gesetzt.
	 */
	String[] werte = new String[dbtablefx.spaltentitel.length];
	for (int i = 0; i < werte.length; i++) {
	    werte[i] = "";
	}
	try {
	    werte[0] = String.valueOf(Integer.parseInt(dbtablefx.getCells().get(dbtablefx.getCells().size() -1)[0].getText()) +1);
	} catch (ArrayIndexOutOfBoundsException | NumberFormatException ex)  {
	    System.out.println("fehler beim setzen des defaultwertes[0] (Rechnungsnummer)");
	    werte[0] = "";
	}
	werte[1] = convertTime(LocalDate.now());
	werte[2] = convertTime(LocalDate.now().plus(2 , ChronoUnit.WEEKS));
	return werte;
    }
    
    private String convertTime(LocalDate ld) {
	String zeit = ld.format(DateTimeFormatter.BASIC_ISO_DATE);
	String jahr = zeit.substring(0, 4);
	String monat = zeit.substring(4, 6);
	String tag = zeit.substring(6, 8);
	return tag.concat(".").concat(monat.concat(".").concat(jahr));
    }

    private void resize(Number newValue) {
	/*
	 * setzt die Font-Gr��e entsprechend der Gr��e der gr��e der gr��e des Buttons speichern, welches automatisch mit der Gr��e der stage mitw�chst.
	 * Dazu wird automatisch noch das Padding der Buttons angepasst.
	 */
	fontTracking.set(Font.font(newValue.doubleValue() / ((btnSpeichern.getWidth() * 3) / btnSpeichern.getHeight())));
	menu.setPadding(new Insets(menu.getHeight() /5, menu.getWidth() /20, menu.getHeight() /5, menu.getWidth() /20));
	
    }
    
}