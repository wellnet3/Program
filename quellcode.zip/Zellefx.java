package fx;

import javafx.scene.control.TextField;

public class Zellefx extends TextField {
    
    protected int zeile = 0;
    
    Zellefx() {
	super();
	//this.setMinSize(75, 37.5);
	this.setPrefSize(150, 75);
    }
    
    public void setZeile(int zeile) {
	this.zeile = zeile;
    }

}
