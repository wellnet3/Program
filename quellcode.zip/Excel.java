package fx;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel {
    
    public static final String path = "C:/Users/User/Desktop/Simulation/sample-xlsx-file.xlsx";
    private static ArrayList<String[]> daten;
    
    public static ArrayList<String[]> importiere(final String path) throws EncryptedDocumentException, InvalidFormatException, IOException {
	daten = new ArrayList<String[]>();
	Workbook wb = WorkbookFactory.create(new File(path));
	System.out.println("Workbook has " + wb.getNumberOfSheets() + " sheets : ");
	Sheet sheet = wb.getSheetAt(0);
	DataFormatter dataFormatter = new DataFormatter();
	for (Row row: sheet) {
	    String[] cellvalues = new String[row.getPhysicalNumberOfCells()];
	    System.out.println("cellvalues.length: " + cellvalues.length);
	    for (int i = 0; i < cellvalues.length; i++) {
		cellvalues[i] = dataFormatter.formatCellValue(row.getCell(i));
		System.out.println("cellvalues[" + i + "]: " + cellvalues[i]);
	    }
	    daten.add(cellvalues);
	}
	wb.close();
	return daten;
    }
    
    public static void exportiere(String[] titel, ArrayList<Zellefx[]> zellen, final String path) throws IOException {
	Workbook wb = new XSSFWorkbook();
	Sheet sheet = wb.createSheet();
	Row header = sheet.createRow(0);
	for (int i = 0; i < titel.length; i++) {
	    Cell cell = header.createCell(i);
	    cell.setCellValue(titel[i]);
	}
	for (int i = 0; i < zellen.size(); i++) {
	    Row row = sheet.createRow(i +1);
	    for (int j = 0; j < zellen.get(i).length; j++) {
		Cell cell = row.createCell(j);
		cell.setCellValue(zellen.get(i)[j].getText());
	    }
	}
	
	for (int i = 0; i < zellen.get(0).length; i++) {
	    sheet.autoSizeColumn(i);
	}
	
	FileOutputStream fos = new FileOutputStream(path);
	wb.write(fos);
	fos.close();
	wb.close();
    }

}
