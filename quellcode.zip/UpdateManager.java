package fx;

import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import javax.swing.JOptionPane;

public class UpdateManager {
    
    private static final String urlCheck = "https://raw.githubusercontent.com/wellnet3/project/master/about.txt";
    private static String gitversion;
    private static String link;
    
    public static void update(String cversion) throws IOException, URISyntaxException {
	
	/*
	 *an der URL befindet sich eine txt-datei mit zwei zeilen:
	 *In der ersten Zeile steht die Version des Programms und 
	 *in der zweiten Zeile befindet sich der Pfad zu dem neuen Programm
	 *
	 * Falls die Version des hochgeladenen Programms gr��er ist als die derzeitige Version,
	 * dann wird eine Dialogfenster ge�ffnet mit der URL, die ge�ffnet wird, wenn auf "OK" geklickt wird.
	 */
	
	URL url = new URL(urlCheck);
	BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
	gitversion = in.readLine();
	System.out.println(gitversion);
	link = in.readLine();
	System.out.println(link);
	in.close();
	
	double version = Double.parseDouble(gitversion.substring(9));
	if (version > (Double.parseDouble(cversion))) {
	    if (JOptionPane.showInputDialog(null, "Ein Update ist verf�gbar, es kann unter " + "\n " + "hier heruntergeladen werden (einfach die alte Datei ersetzen). Zum �ffnen einfach auf 'OK' klicken", link).equals(link)) {
		Desktop desktop = Desktop.getDesktop();
		desktop.browse(new URI(link));
	    }
	}
    }

}
